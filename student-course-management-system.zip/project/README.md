# Card Catalog — Student Course Management & Learning Progress Tracking System

A complete, interactive student course management system. Every page is
functional: register, log in, browse and enroll in courses, work through
modules, track progress, and print a certificate on completion. Admins get
their own dashboard to manage the course catalog.

## Run it

No build step and no server required.

1. Open `frontend/html/index.html` directly in a browser, **or**
2. For the most reliable experience (some browsers restrict storage on
   `file://` URLs), serve the `frontend` folder with any static server, e.g.:
   ```
   cd frontend
   python3 -m http.server 8000
   ```
   then visit `http://localhost:8000/html/index.html`.

Data is stored in the browser via `localStorage`/`sessionStorage`, so it's
persistent across visits on the same browser but private to each visitor —
there's nothing to install or configure.

## Try it

- **Register** a student account, then **log in**.
- **Browse Courses** → open a course → **Enroll**.
- Go to **My Courses** → **Continue Learning** → open modules, mark them
  complete, watch a video lesson.
- Check **Progress** and **Notifications** as you go.
- Complete every module in a course to unlock its **Certificate** (printable).
- Log out and log back in as an administrator to manage the catalog:
  - Email: `admin@campus.edu`
  - Password: `admin123`
  - From the admin dashboard: **Manage Courses** → add, edit, or delete
    courses; each edit is reflected immediately for students.

## Structure

```
frontend/
  html/     21 pages, one per module in the system (see below)
  css/      style.css — single shared design system
  js/       app.js — data model, auth, and all page logic
backend/
  README.md — suggested structure for a real API layer later
```

## Modules covered

| Module | Pages |
|---|---|
| 1. User Authentication | index, register, login, forgot-password, reset-password |
| 2. Course Management (admin) | courses, add-course, edit-course |
| 3. Course Enrollment | browse-courses, course-details, my-courses, enrollment-success |
| 4. Learning Management | course-content, module, video-player, materials |
| 5. Progress Tracking | progress, certificate |
| 6. Dashboard | student-dashboard, admin-dashboard |
| 7. Notifications | notifications |

## Notes

- This is a genuinely working prototype, not a mockup — every button, form,
  and progress bar reads and writes real state.
- `frontend/js/app.js` is organized so the storage layer (`Students`,
  `Courses`, `Enrollments`, `Notifications`) is separate from the page
  controllers (`PAGES.*`). Swapping `localStorage` for `fetch()` calls to a
  real backend later shouldn't require rewriting the pages.
- Editing a course's module list in the admin panel re-numbers module IDs;
  in a production system you'd keep IDs stable independent of order.
